# -*- coding: utf-8 -*-


class CellMapsPPIDownloaderError(Exception):
    """
    Base exception for CellMapsPPIDownloader
    """
    pass
