# -*- coding: utf-8 -*-

"""Top-level package for cellmaps_ppidownloader."""

__author__ = 'Ideker Lab CM4AI team'
__email__ = 'tools@cm4ai.org'
__version__ = '0.1.0a3'
__repo_url__ = 'https://github.com/idekerlab/cellmaps_ppidownloader'
__description__ = 'A tool to download APMS data for CM4AI pipeline'
