=====
Usage
=====

This page should provide information on how to use cellmaps_generate_hierarchy

In a project
--------------

To use CM4AI Generate Hierarchy in a project::

    import cellmaps_generate_hierarchy

On the command line
---------------------

For information invoke :code:`cellmaps_generate_hierarchycmd.py -h`

**Example usage**

**TODO:** Add information about example usage

.. code-block::

   cellmaps_generate_hierarchycmd.py # TODO Add other needed arguments here

Via Docker
---------------

**Example usage**

**TODO:** Add information about example usage


.. code-block::

   docker run -v `pwd`:`pwd` -w `pwd` idekerlab/cellmaps_generate_hierarchy:0.1.0 cellmaps_generate_hierarchycmd.py # TODO Add other needed arguments here


