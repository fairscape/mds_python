Development Process
=====================

TODO need to denote that development go on
``dev`` branch and each user should have their own
branch and pull request into ``dev``
