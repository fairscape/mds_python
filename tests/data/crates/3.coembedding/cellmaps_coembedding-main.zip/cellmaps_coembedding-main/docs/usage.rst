=====
Usage
=====

This page should provide information on how to use cellmaps_coembedding

In a project
--------------

To use CM4AI Generate PPI in a project::

    import cellmaps_coembedding

On the command line
---------------------

For information invoke :code:`cellmaps_coembeddingcmd.py -h`

**Example usage**

**TODO:** Add information about example usage

.. code-block::

   cellmaps_coembeddingcmd.py # TODO Add other needed arguments here

Via Docker
---------------

**Example usage**

**TODO:** Add information about example usage


.. code-block::

   docker run -v `pwd`:`pwd` -w `pwd` idekerlab/cellmaps_coembedding:0.1.0 cellmaps_coembeddingcmd.py # TODO Add other needed arguments here


