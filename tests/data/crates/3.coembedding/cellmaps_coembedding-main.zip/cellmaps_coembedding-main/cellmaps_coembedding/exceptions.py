# -*- coding: utf-8 -*-


class CellmapsCoEmbeddingError(Exception):
    """
    Base exception for cellmaps_coembedding
    """
    pass
