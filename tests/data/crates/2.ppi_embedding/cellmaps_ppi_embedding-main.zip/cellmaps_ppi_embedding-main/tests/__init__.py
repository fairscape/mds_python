# -*- coding: utf-8 -*-

"""Unit test package for cellmaps_ppi_embedding."""
