# -*- coding: utf-8 -*-


class CellMapsPPIEmbeddingError(Exception):
    """
    Base exception for CellMapsPPIEmbedding
    """
    pass
